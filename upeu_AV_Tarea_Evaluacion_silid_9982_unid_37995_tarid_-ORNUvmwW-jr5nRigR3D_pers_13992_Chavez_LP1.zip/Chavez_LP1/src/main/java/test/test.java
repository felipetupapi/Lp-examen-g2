package test;

import pe.edu.upeu.config.Conexion;

public class test {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			if(Conexion.getConexion()!=null) {
				System.out.println("Conectado");
				
			}
		}
}
