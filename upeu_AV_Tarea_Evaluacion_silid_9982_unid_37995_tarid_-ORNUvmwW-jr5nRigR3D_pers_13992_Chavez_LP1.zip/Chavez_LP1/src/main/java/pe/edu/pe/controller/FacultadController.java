package pe.edu.pe.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import pe.edu.upeu.dao.FacultadDao;
import pe.edu.upeu.daoImpl.FacultadDaoImpl;
import pe.edu.upeu.entity.Facultad;


/**
 * Servlet implementation class EscuelaController
 */
@WebServlet("/facultad")
public class FacultadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FacultadDao edao = new FacultadDaoImpl();
	private Gson gson = new Gson();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FacultadController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			PrintWriter out = response.getWriter();
			int op = Integer.parseInt(request.getParameter("opc"));

			switch (op) {
			case 1:
				out.println(gson.toJson(edao.readAll()));
				break;
			case 2:
				int idc = Integer.parseInt(request.getParameter("id"));
				out.println(gson.toJson(edao.read(idc)));
				break;
			case 3:
				Facultad esc1 = new Facultad();
				esc1.setNombre(request.getParameter("nombre"));
				out.println(gson.toJson(edao.create(esc1)));
				break;
			case 4:
				Facultad esc2 = new Facultad();
				esc2.setIdfacultad(Integer.parseInt(request.getParameter("id")));
				esc2.setNombre(request.getParameter("nombre"));
				out.println(gson.toJson(edao.update(esc2)));
				break;
			case 5:
				out.println(gson.toJson(edao.delete(Integer.parseInt(request.getParameter("id")))));
				break;
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
