package pe.edu.upeu.dao;

import pe.edu.upeu.entity.Facultad;
import pe.edu.upeugeneral.Generic;

public interface FacultadDao extends Generic<Facultad> {

}
