$(document).ready(function(){
	listar();
});

$("#save").click(function() {
	let cat = $("#catNuevo").val();
	$.post("categoria", { "nombre": cat, "opc": 3 }, function() {
		listar();
	});
	limpiear();
	cerrarNuevo();

});
$("#edit").click(function() {
	let cat = $("#catEdit").val();
	let id = $("#idEdit").val();
	$.post("categoria", { "id": id, "nombre": cat, "opc": 4 }, function() {
		listar();
	});
	cerrarEdit();

});
function editar(id) {
	$.get("categoria", { "id": id, "opc": 2 }, function(data) {
		var x = JSON.parse(data);
		$("#catEdit").val(x.nombre);
		$("#idEdit").val(x.idcategoria);
	});
	mostrarEdit();
}
function listar() {
	$.get("categoria", { "opc": 1 }, function(data) {
		var x = JSON.parse(data);
		$("#tablita tbody tr").remove();
		x.forEach(function(item) {
			$("#tablita").append("<tr><td>" + item.nombre + "</td><td><a href='#' onclick='editar(" + item.idcategoria + ")' class='btn btn-warning'><i class='far fa-edit'></i></a></td><td><a href='#' onclick='eliminar(" + item.idcategoria + ")' class='btn btn-danger'><i class='fas fa-trash-alt'></i></a></td></tr>"
			);
		});
	});
}
function eliminar(id) {

	$.get("categoria", { "id": id, "opc": 5 }, function() {
		listar();
	});
}
function limpiear() {
	$("#catNuevo").val("");
}
function cerrarNuevo() {
	const modalInstance = bootstrap.Modal.getInstance(document.getElementById('cadModalNuevo'));
	if (modalInstance) {
		modalInstance.hide();
	}
}
function cerrarEdit() {
	const modalInstance = bootstrap.Modal.getInstance(document.getElementById('cadModalEdit'));
	if (modalInstance) {
		modalInstance.hide();
	}
}
function mostrarEdit() {
	const modal = new bootstrap.Modal(document.getElementById('cadModalEdit'));
	modal.show();

}