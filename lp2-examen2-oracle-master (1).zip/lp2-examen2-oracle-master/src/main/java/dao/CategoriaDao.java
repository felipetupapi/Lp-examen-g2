package dao;

import entity.Categoria;
import general.Generic;

public interface CategoriaDao extends Generic<Categoria>{

}
