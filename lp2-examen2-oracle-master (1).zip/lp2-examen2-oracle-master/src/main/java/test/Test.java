package test;

import com.google.gson.Gson;

import config.Conexion;
import dao.CategoriaDao;
import daoImpl.CategoriaDaoImpl;

public class Test {
 static CategoriaDao cdao = new CategoriaDaoImpl();
 static Gson gson = new Gson();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(Conexion.getConexion()!=null) {
			System.out.println("SI");
			System.out.println(cdao.readAll());
		}else {
			System.out.println("NO");
		}
	}

}
