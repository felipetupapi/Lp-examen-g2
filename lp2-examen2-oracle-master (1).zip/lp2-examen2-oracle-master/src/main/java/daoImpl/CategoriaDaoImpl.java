package daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import config.Conexion;
import dao.CategoriaDao;
import entity.Categoria;

public class CategoriaDaoImpl implements CategoriaDao {
	private PreparedStatement ps;
	private ResultSet rs;
	private Connection cx;

	@Override
	public int create(Categoria t) {
		// TODO Auto-generated method stub
		String SQL = "INSERT INTO categoria (nombre) VALUES(?)";
		int x = 0;
		try {
			cx = Conexion.getConexion();
			ps = cx.prepareStatement(SQL);
			ps.setString(1, t.getNombre());
			x = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		return x;
	}

	@Override
	public int update(Categoria t) {
		// TODO Auto-generated method stub
		String SQL = "UPDATE categoria SET nombre=? WHERE idcategoria=?";
		int x = 0;
		try {
			cx = Conexion.getConexion();
			ps = cx.prepareStatement(SQL);
			ps.setString(1, t.getNombre());
			ps.setInt(2, t.getIdcategoria());
			x = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		return x;
	}

	@Override
	public int delete(int id) {
		String SQL = "DELETE FROM categoria WHERE idcategoria=?";
		int x = 0;
		try {
			cx = Conexion.getConexion();
			ps = cx.prepareStatement(SQL);
			ps.setInt(1, id);
			x = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		return x;
	}

	@Override
	public Categoria read(int id) {
		String SQL = "SELECT *FROM categoria WHERE idcategoria=?";
		int x = 0;
		Categoria cat = new Categoria();
		try {
			cx = Conexion.getConexion();
			ps = cx.prepareStatement(SQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while(rs.next()) {
				cat.setIdcategoria(rs.getInt("idcategoria"));
				cat.setNombre(rs.getString("nombre"));
			}
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		return cat;
	}

	@Override
	public List<Categoria> readAll() {
		String SQL = "SELECT *FROM categoria";
		int x = 0;
		List<Categoria> lista = new ArrayList<>();
		try {
			cx = Conexion.getConexion();
			ps = cx.prepareStatement(SQL);
			rs = ps.executeQuery();
			while(rs.next()) {
				Categoria cat = new Categoria();
				cat.setIdcategoria(rs.getInt("idcategoria"));
				cat.setNombre(rs.getString("nombre"));
				lista.add(cat);
			}
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error: "+e);
		}
		return lista;
	}

}
